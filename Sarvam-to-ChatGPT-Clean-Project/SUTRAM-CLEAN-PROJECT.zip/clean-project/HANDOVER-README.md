# Sutram — clean project, for whole-project audit

This archive is the **complete current project tree**, with the collaboration handoff
folders removed so nothing from the history confuses the audit.

**Read `CLEAN-PROJECT-BRIEF.md` first.** It states what is being asked, the state the
project was measured in, a real defect already found, and what to return.

Build (NASM and a linker are all you need):

    nasm -f elf64 -I. src/sutram_compiler.asm -o /tmp/c.o && ld -o sutram_compiler /tmp/c.o
    nasm -f elf64 ide/sutram_gui_linux.asm -o /tmp/g.o && ld -o sutram-gui /tmp/g.o

Return your work in `ChatGPT-to-Sarvam-Clean/` on the repo.
