@echo off
cd /d "%~dp0"
start "" sutram-ide-gui.exe
