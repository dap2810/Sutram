@echo off
cd /d "%~dp0"
sutram.exe --help
pause
