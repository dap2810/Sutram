# Round 42 — pending native compiler fixtures

These fixtures are **not** part of the current regression suite and contain **no invented `.out` or `.compile_fail` goldens**. Each `EXPECTED.txt` specifies only expected status/diagnostic *shape*. Assemble the modified NASM compiler, invoke it against `main.sm` from each case's folder (the module lookup is `lib/`), record actual stdout/stderr and process status, and only then promote these into the standard `tests/expect/` format. The currently available GitHub `main` tree has no `tests/` directory to promote them into.

Use the opt-in header `# sutram-module-v1` at byte 0 for modern root and modules. `niryat name` is a standalone declaration. Qualified calls are `alias__name`; alias isolation must not bypass private access. Keep non-opt-in legacy source behavior exactly.

**Caution:** `07_success_sutra_constant` is a language-contract probe. The current compiled-language ability to define exported module-level `sutra` constants is unverified. Do not mark it a native acceptance test until source grammar is confirmed.
