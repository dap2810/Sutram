# Sutram Windows GUI — owner manual acceptance (Round 42)

**No actual GUI run or screenshots were performed in this handoff.** Use the existing Windows GUI build from a trusted package only; do not disable UAC, antivirus, firewall or other security controls. Launch as a standard user. Write actual results, build hash and screenshots separately.

1. **Launch:** Open the GUI IDE normally without elevation. Expected: a responsive main window, editor, menus, run/compile controls and output pane; no fatal startup dialog.
2. **Editor / line numbers:** Enter 3 lines with `mukhya()`, `likha("Namaste")` and closing brace; move cursor and scroll. Expected: line number gutter tracks content, caret does not clip.
3. **Devanagari source:** Open a `.sm` containing Devanagari keywords and save it as UTF-8. Reopen it. Expected: bytes/characters preserved with no replacement glyphs, truncation or corruption.
4. **Native highlighting:** Type Hindi and Tamil keywords from installed packs plus ASCII Sanskrit keywords. Expected: recognized keywords highlighted *only in code*, not in quoted strings, `#` comments or `//` comments.
5. **Run/compile:** Compile a known passing `hello.sm` and run it. Expected: output pane shows the expected literal and no invisible crash. Confirm output target `.exe` is a Windows PE32+ program.
6. **File dialogs:** Open a file whose name includes Unicode characters, save a copy under a normal user-owned directory. Expected: dialog completes; Unicode path works and file content remains identical.
7. **Failure path:** Attempt to compile an intentionally malformed program. Expected: visible actionable diagnostic; GUI stays responsive and does not run a stale output binary.
8. **Round 42 scenario only after native compiler implementation:** Compile a modern module with `niryat` and a private function. Expected: public call works, imported qualified private call yields `E_PRIVATE_SYMBOL`, visible in IDE output. **Do not mark this passing until actually observed.**

Record for each: PASS / FAIL / NOT RUN; Windows version; compiler SHA-256; GUI SHA-256; screenshots; exact visible output. GUI static assembly validation is not visual acceptance.
