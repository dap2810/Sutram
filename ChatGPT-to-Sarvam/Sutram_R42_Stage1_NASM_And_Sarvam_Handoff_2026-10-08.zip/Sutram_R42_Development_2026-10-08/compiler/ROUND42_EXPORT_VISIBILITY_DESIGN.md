# Round 42 — `niryat` visibility, implementation plan and failure conditions

**Status:** engineering design + independently run Python reference tests, **NOT a compiler implementation**. This plan applies to verified root `main` commit `751cbd3be02a7576954ec1bcca3304a7c5b87b36` (2026-10-09T02:53:21Z). GitHub may have advanced by the time work resumes; re-check the branch HEAD and compiler bytes.

## Compatibility boundary

Opt in only if the root begins with exactly `# sutram-module-v1` followed by end of line. Keep the old `ayojan` expansion and all legacy emitted program bytes unchanged without this opt-in. A module without its own version marker remains legacy rather than silently acquiring private symbols. Sanskrit/Romanized keyword `niryat` is a standalone declaration: `niryat length`; a module uses ordinary `prakriya length(...)` or `sutra MAX = ...` definitions. No new runtime format is needed in Round 42.

## Required semantic table

| Importer reference or module declaration | Expected |
|---|---|
| `niryat foo` + actual `prakriya foo` | Public `foo` |
| `niryat MAX` + actual `sutra MAX` | Public constant `MAX` (confirm current grammar supports module-level constants) |
| `niryat foo` but no definition | `E_EXPORT_UNDEFINED` at the module's export declaration line |
| qualified `alias__private` where private exists | `E_PRIVATE_SYMBOL` at importing source line |
| qualified `alias__missing` where symbol is absent | `E_EXPORT_UNDEFINED` at importing source line |
| two different unqualified imports export `foo` | `E_EXPORT_COLLISION`, naming both modules |
| same export `foo` imported under distinct explicit aliases | Legal, resolves separately |
| duplicate `niryat foo` in one module | `E_EXPORT_DUPLICATE` (existing reference model; optional extra diagnostic beyond Sarvam's three mandatory names) |
| non-opt-in source | Preserve existing behavior and bytes |

Diagnostics should use `filename:physical-line: Sutram Error [CODE]: description`, with escaped/unambiguous module and symbol names. Native golden output must be captured from real compiler execution, not invented from the desired diagnostic.

## Suggested NASM implementation sequence

1. After `graph_preflight_v1` identifies the opt-in root, reuse the bounded dependency graph and per-module `graph_buffers`, `graph_lengths`, `graph_names`, `graph_paths`. Before destructive `expand_imports`, scan **each** reachable module for its own header, top-level `niryat name`, `prakriya name`, and `sutra name` (module-level grammar needs verification). Enforce capacity checks on every string/table insertion; do not use unchecked 64-byte alias slots.
2. Validate export declarations against locally defined symbols and reject duplicate declarations. Record provenance `module-id, symbol name, kind, declaration line` so error codes and locations do not depend on expansion order.
3. Resolve visible unqualified exports, detecting collisions between distinct exporting modules before any AST function-table overwrite. Keep qualified alias names separate and enforce uniqueness. Do not conflate the module identity with alias identity: existing R40 duplicate-module handling and diamond deduplication must remain intact.
4. **Enforce actual privacy.** Merely scanning `niryat` lines is insufficient: expanded modules still contribute global AST function symbols. Rewrite/lower module-private declarations and their internal uses to collision-free internal names, then rewrite public references to the chosen external names. The present `ns_rewrite_funcs` covers identifier followed by `(` but not `sutra` value uses; teach the opt-in path to rewrite both consistently without touching comments, strings or ordinary identifier substrings. Do not mutate legacy text rewriting.
5. Check qualified references against module's export set, distinguishing defined-private from completely undefined names. Reject private qualified access even if the private symbol has been internally renamed. Include file/line origins from the original source, not the rewritten concatenated source.
6. Consume `niryat` directives in the compiler's opt-in preprocessing path so they do not become illegal tokens for `lex`/`parse_program`. Retain line breaks to preserve useful diagnostics. Leave header comments untouched. Protect against malformed directives, token-prefix matches, strings/comments, recursive modules, and source-capacity overruns.
7. Compile both Linux ELF and Windows PE32+ outputs **from the modified assembly source** and run native positive/negative fixtures. Recreate true `.out`, `.exit`, `.compile_fail` goldens only after observing the actual output. Run 181 legacy tests + at least four new fixtures, all 12 codegen gates, native-script packs and R41 cycle/missing acceptance, plus X11/Windows GUI static or manual checks.
8. Before passing to Sarvam, generate exact changed-file SHA-256 manifest and unified diff, test `git apply` and reverse apply against the correct base, verify `git` branch head, and keep `main` untouched until independent acceptance.

## Source locations observed in current GitHub

- `src/sutram_compiler.asm:1786-1795`: `graph_preflight_v1` before `expand_imports`, `lex`, and `parse_program`.
- `src/sutram_compiler.asm:1926-1955`: exact opt-in header detection.
- `src/sutram_compiler.asm:1958-2270`: `graph_scan` and `graph_visit`, recursive imports, per-module source buffers and path provenance.
- `src/sutram_compiler.asm:2398-2878`: transitive import expansion and duplicate module table, including namespaced path at `2790-2813`.
- `src/sutram_compiler.asm:2887-3027`: top-level function collector.
- `src/sutram_compiler.asm:3029-3218`: lexical rename/emit implementation for qualified names.
- `tools/module_graph_reference.py`: existing independent reference model, extended in accompanying proposed patch to recognize `sutra NAME = value` and distinguish absent from private names.

## Known blockers at time of preparation

1. GitHub App reports `403 Resource not accessible by integration` for branch creation; nothing was committed.
2. Fresh GitHub `main` tree contains **no `tests/` directory** (despite handoff referencing 181 native tests and paths under `tests/gui/`). Rebuild cannot claim full legacy acceptance from this checkout.
3. Local host has `/usr/bin/ld` but no `nasm`; network-backed clone also fails (`Could not resolve host: github.com`). Native compiler build and runtime cannot be represented as passing.

The correct next step is to obtain write access and a complete verified test tree, then implement NASM compiler lowering. Reference-oracle behavior is a model of the target contract, **not proof that the compiler obeys it**.
