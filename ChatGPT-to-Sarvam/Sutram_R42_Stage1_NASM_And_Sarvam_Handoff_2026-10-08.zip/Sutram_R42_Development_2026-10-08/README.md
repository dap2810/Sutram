# Sutram R42 — new Stage-1 native compiler proposal and Sarvam handoff

This package advances the earlier Round 42 **reference-only** review with a first proposed edit to `src/sutram_compiler.asm` and a native acceptance runner. It is **not a finished Round 42 feature**, **not assembled**, and **not merged**. The existing Python reference contract and eight pending native fixtures are preserved.

## Read first

`ChatGPT-to-Sarvam/ROUND-42-STAGE1-2026-10-08.md`

## To apply in a complete GitHub checkout (review ONLY)

```bash
python3 native_patch/apply_r42_stage1.py \
  src/sutram_compiler.asm /tmp/sutram_compiler_r42_stage1.asm

diff -u src/sutram_compiler.asm /tmp/sutram_compiler_r42_stage1.asm
```

The patcher requires the independently recorded exact source SHA-256. It will refuse any stale source or double patch. An unassembled review patch is also included as `native_patch/R42_STAGE1_UNASSEMBLED.patch`; the complete original source cannot be distributed from this environment, so Sarvam should verify against their own correct source checkout.

## Tests run here

- Reference-model unit tests: 13/13 passed.
- Pending fixture-to-oracle checks: 8/8 passed.
- Static source-patcher tests: 5/5 passed.
- Native compiler assembly and full regression suite: unavailable / not run.
- Real GUI visual test: not run.

## Incomplete native feature

Only opt-in `niryat` declaration existence checks and lexical removal are supplied as prototype NASM edits. The mandatory `E_EXPORT_COLLISION`, `E_PRIVATE_SYMBOL`, true private symbol isolation, qualified undefined diagnostic and top-level constant support are **not implemented**. Do not merge Stage 1 as finished.

## Delivery

GitHub branch creation rejected with 403 from the connected integration; nothing was pushed to the repo. This ZIP is the handoff payload for Sarvam, to be uploaded after permissions are corrected or forwarded by the project owner.
