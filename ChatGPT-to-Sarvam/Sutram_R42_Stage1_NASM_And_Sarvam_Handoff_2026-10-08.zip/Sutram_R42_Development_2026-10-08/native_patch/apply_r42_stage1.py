#!/usr/bin/env python3
"""Conservative, fail-closed R42 NASM source transform for Sarvam code review.

This is a STAGE-1 compiler edit, NOT full export visibility. It validates that
an opt-in niryat declaration has a definition in its own module and removes
niryat directive bytes before lexing. It does not yet enforce access privacy.

Apply against GitHub compiler blob b05d536b369923a023fc81fcdda2d2d4d324745f
at main 751cbd3 (unchanged at subsequent main aab7544).
"""
from __future__ import annotations
import argparse
import hashlib
from pathlib import Path

# Distinct markers keep the legacy path byte-for-byte untouched when flag is 0.
STAGE1_CODE = r'''
; ============================================================
; R42 STAGE 1 — opt-in niryat validation and lexical consumption.
; This is an INCOMPLETE visibility implementation. Do not merge until R42
; collision, private-symbol isolation, qualified access and native tests land.
; No Python is required by the compiled Sutram compiler/runtime.
; ============================================================
r42_validate_export_declarations:
    cmp qword [rel r42_enabled],0
    je .disabled
    push rbx
    push r12
    push r13
    push r14
    push r15
    xor r12,r12                        ; module ordinal
.module:
    cmp r12,[rel graph_count]
    jae .finished
    mov rax,r12
    shl rax,16
    lea r13,[rel graph_buffers]
    add r13,rax                        ; this module's source bytes
    mov rax,r12
    shl rax,3
    lea rbx,[rel graph_lengths]
    mov rax,[rbx+rax]
    mov [rel r42_scan_len],rax
    xor r14,r14                        ; byte position
    mov r15,1                          ; 1-based physical line
.line:
    cmp r14,[rel r42_scan_len]
    jae .next_module
    lea rbx,[r13+r14]
.skip_indent:
    mov rax,rbx
    sub rax,r13
    cmp rax,[rel r42_scan_len]
    jae .next_line
    cmp byte [rbx],' '
    je .indent_one
    cmp byte [rbx],9
    jne .check_export
.indent_one:
    inc rbx
    jmp .skip_indent
.check_export:
    mov rax,rbx
    sub rax,r13
    mov rcx,[rel r42_scan_len]
    sub rcx,rax
    cmp rcx,7
    jb .next_line
    cmp dword [rbx],0x7972696e      ; 'niry'
    jne .next_line
    cmp word [rbx+4],0x7461         ; 'at'
    jne .next_line
    cmp byte [rbx+6],' '
    je .read_export
    cmp byte [rbx+6],9
    jne .next_line
.read_export:
    add rbx,6
.whitespace:
    mov al,[rbx]
    cmp al,' '
    je .ws_one
    cmp al,9
    jne .name
.ws_one:
    inc rbx
    jmp .whitespace
.name:
    lea rdi,[rel r42_export_name]
    xor ecx,ecx
.copy:
    mov rax,rbx
    sub rax,r13
    cmp rax,[rel r42_scan_len]
    jae .name_done
    mov al,[rbx]
    cmp al,'_'
    je .copy_char
    cmp al,'0'
    jb .name_done
    cmp al,'9'
    jbe .copy_char
    cmp al,'A'
    jb .name_done
    cmp al,'Z'
    jbe .copy_char
    cmp al,'a'
    jb .name_done
    cmp al,'z'
    ja .name_done
.copy_char:
    cmp rcx,63
    jae .name_done
    mov [rdi+rcx],al
    inc rcx
    inc rbx
    jmp .copy
.name_done:
    mov byte [rdi+rcx],0
    ; A malformed or missing name has no matching definition: reject closed.
    call r42_find_local_definition
    test rax,rax
    jnz .next_line
    mov rax,r12
    shl rax,9
    lea rdi,[rel graph_paths]
    add rdi,rax
    mov rsi,r15
    lea rdx,[rel graph_msg_export_undefined]
    lea rcx,[rel graph_export_undefined_prefix]
    lea rax,[rel r42_export_name]
    mov [rel graph_detail_ptr],rax
    call graph_error                   ; never returns
.next_line:
    cmp r14,[rel r42_scan_len]
    jae .next_module
    mov al,[r13+r14]
    inc r14
    cmp al,10
    jne .next_line
    inc r15
    jmp .line
.next_module:
    inc r12
    jmp .module
.finished:
    pop r15
    pop r14
    pop r13
    pop r12
    pop rbx
.disabled:
    ret

; r13=module start, [r42_scan_len]=byte count; [r42_export_name]=word.
; Return rax=1 for line-leading prakriya or sutra declaration, else 0.
; Not a full semantic scope parser; native test and refinement required.
r42_find_local_definition:
    push rbx
    push rdi
    push rsi
    push rdx
    push r8
    lea r8,[r13]
    add r8,[rel r42_scan_len]
    mov rbx,r13
.scan:
    cmp rbx,r8
    jae .absent
    mov rdx,rbx
.indent:
    cmp rdx,r8
    jae .next_line
    cmp byte [rdx],' '
    je .indent_step
    cmp byte [rdx],9
    jne .keyword
.indent_step:
    inc rdx
    jmp .indent
.keyword:
    lea rax,[rdx+9]
    cmp rax,r8
    ja .maybe_sutra
    cmp dword [rdx],0x6b617270  ; 'prak'
    jne .maybe_sutra
    cmp dword [rdx+4],0x61796972 ; 'riya'
    jne .maybe_sutra
    mov al,[rdx+8]
    cmp al,' '
    je .function
    cmp al,9
    jne .maybe_sutra
.function:
    add rdx,8
    jmp .after_keyword
.maybe_sutra:
    lea rax,[rdx+6]
    cmp rax,r8
    ja .next_line
    cmp dword [rdx],0x72747573 ; 'sutr'
    jne .next_line
    cmp byte [rdx+4],'a'
    jne .next_line
    mov al,[rdx+5]
    cmp al,' '
    je .constant
    cmp al,9
    jne .next_line
.constant:
    add rdx,5
.after_keyword:
    cmp rdx,r8
    jae .next_line
    cmp byte [rdx],' '
    je .space
    cmp byte [rdx],9
    jne .compare
.space:
    inc rdx
    jmp .after_keyword
.compare:
    mov rdi,rdx
    lea rsi,[rel r42_export_name]
    call r42_match_definition_name
    test rax,rax
    jnz .found
.next_line:
    cmp rbx,r8
    jae .absent
    mov al,[rbx]
    inc rbx
    cmp al,10
    jne .next_line
    jmp .scan
.found:
    mov eax,1
    jmp .exit
.absent:
    xor eax,eax
.exit:
    pop r8
    pop rdx
    pop rsi
    pop rdi
    pop rbx
    ret

; Compare full lexeme, never a prefix: rdi=module declaration word,
; rsi=export name, r8=end of graph buffer. Returns 1 if equal.
r42_match_definition_name:
.match:
    cmp rdi,r8
    jae .no
    mov al,[rsi]
    test al,al
    jz .boundary
    cmp al,[rdi]
    jne .no
    inc rsi
    inc rdi
    jmp .match
.boundary:
    cmp rdi,r8
    jae .yes
    mov al,[rdi]
    cmp al,'('
    je .yes
    cmp al,' '
    je .yes
    cmp al,9
    je .yes
    cmp al,'='
    je .yes
.no:
    xor eax,eax
    ret
.yes:
    mov eax,1
    ret

; Opt-in source ONLY. Blank niryat directive bytes before normal lexing,
; preserving physical line lengths and newline numbers. Assumes directives
; appear outside multiline strings (must be checked in subsequent R42 stage).
r42_blank_niryat_directives:
    cmp qword [rel r42_enabled],0
    je .done
    lea rdx,[rel source_buf]
    mov r8,[rel source_len]
    xor r9,r9
.line:
    cmp r9,r8
    jae .done
    mov r10,r9
    lea r11,[rdx+r10]
.spaces:
    cmp r10,r8
    jae .done
    mov al,[rdx+r10]
    cmp al,' '
    je .space_one
    cmp al,9
    jne .check
.space_one:
    inc r10
    jmp .spaces
.check:
    lea r11,[rdx+r10]
    mov rax,r8
    sub rax,r10
    cmp rax,7
    jb .next_line
    cmp dword [r11],0x7972696e
    jne .next_line
    cmp word [r11+4],0x7461
    jne .next_line
    cmp byte [r11+6],' '
    je .erase
    cmp byte [r11+6],9
    jne .next_line
.erase:
    mov r10,r9
.erase_one:
    cmp r10,r8
    jae .done
    cmp byte [rdx+r10],10
    je .next_line
    mov byte [rdx+r10],' '
    inc r10
    jmp .erase_one
.next_line:
    cmp r9,r8
    jae .done
    mov al,[rdx+r9]
    inc r9
    cmp al,10
    jne .next_line
    jmp .line
.done:
    ret
'''

CHANGES = [
  ("    graph_msg_missing db 'E_MODULE_MISSING', 0\n",
   "    graph_msg_missing db 'E_MODULE_MISSING', 0\n"
   "    graph_msg_export_undefined db 'E_EXPORT_UNDEFINED',0\n"
   "    graph_export_undefined_prefix db 'export has no local definition: ',0\n"),
  ("    graph_scratch_names resb (IMPORT_NAMES_CAP + 1) * 64\n",
   "    graph_scratch_names resb (IMPORT_NAMES_CAP + 1) * 64\n"
   "    r42_enabled resq 1\n"
   "    r42_scan_len resq 1\n"
   "    r42_export_name resb 64\n"),
  ("    call graph_preflight_v1\n    ; Expand imports (inline .smlib files)\n    call expand_imports\n    ; Lex\n    call lex\n",
   "    call graph_preflight_v1\n"
   "    call r42_validate_export_declarations\n"
   "    ; Expand imports (inline .smlib files)\n    call expand_imports\n"
   "    call r42_blank_niryat_directives\n"
   "    ; Lex\n    call lex\n"),
  ("graph_preflight_v1:\n    lea rdi,[rel source_buf]\n",
   "graph_preflight_v1:\n    mov qword [rel r42_enabled],0\n    lea rdi,[rel source_buf]\n"),
  (".go:\n    mov qword [rel graph_count],0\n",
   ".go:\n    mov qword [rel r42_enabled],1\n    mov qword [rel graph_count],0\n"),
  ("graph_preflight_v1:\n", STAGE1_CODE + "\ngraph_preflight_v1:\n"),
]


def update(src: str) -> str:
    if "r42_validate_export_declarations:" in src:
        raise ValueError("R42 stage1 already present; refusing repeat")
    for old,new in CHANGES:
        n=src.count(old)
        if n!=1:
            raise ValueError(f"baseline anchor not unique or missing (count={n}): {old[:75]!r}")
        src=src.replace(old,new,1)
    return src


def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument("input",type=Path)
    ap.add_argument("output",type=Path)
    ap.add_argument("--sha",default="cd7a290883c085685a8ef71d8486e8a23a43b5498f4588fd7b08ef2290978598",help="Expected original file SHA-256 (NOT Git blob SHA); refuse stale sources")
    args=ap.parse_args()
    before=args.input.read_bytes()
    digest=hashlib.sha256(before).hexdigest()
    if args.sha and args.sha.lower()!=digest:
        raise SystemExit(f"source SHA mismatch: {digest} != {args.sha}")
    after=update(before.decode('utf-8')).encode('utf-8')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_bytes(after)
    print(f"source_in_sha256={digest}")
    print(f"source_out_sha256={hashlib.sha256(after).hexdigest()}")
    print(f"source_out={args.output}")
    print("status=UNASSEMBLED; R42 VISIBILITY INCOMPLETE")

if __name__=='__main__': main()
