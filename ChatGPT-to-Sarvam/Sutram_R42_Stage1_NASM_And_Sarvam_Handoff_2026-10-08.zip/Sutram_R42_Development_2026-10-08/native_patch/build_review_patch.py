"""Construct a reviewable unified R42 stage1 diff from precise GitHub line anchors.

No claim is made that it was applied to/assembled from complete source here.
The official application path is apply_r42_stage1.py with SHA verification.
"""
from pathlib import Path
import importlib.util
import difflib
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('apply_r42_stage1',R/'apply_r42_stage1.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
# The real baseline contains 17034 lines; only these exact windows are used
# as patch contexts. All intervening lines are spacers and excluded by n=1.
lines=['; R42 PATCH-BUILDER SPACER\n']*2020
slots={
677:"    graph_v1_header db '# sutram-module-v1', 0",
678:"    graph_msg_cycle db 'E_MODULE_CYCLE', 0",
679:"    graph_msg_missing db 'E_MODULE_MISSING', 0",
680:"    graph_msg_limit db 'E_MODULE_LIMIT', 0",
681:"    graph_msg_invalid db 'E_MODULE_INVALID', 0",
787:"    graph_lengths resq IMPORT_NAMES_CAP",
788:"    graph_scratch_names resb (IMPORT_NAMES_CAP + 1) * 64",
789:"    rachana_defs resb RACHANA_CAP * 256 ; [name_ptr(8)][field_count(8)][fields...]",
1786:"    ; R41: opt-in module-v1 graph preflight runs BEFORE destructive expansion.",
1787:"    ; The legacy import and generated-code path is byte-for-byte unchanged.",
1788:"    call graph_preflight_v1",
1789:"    ; Expand imports (inline .smlib files)",
1790:"    call expand_imports",
1791:"    ; Lex",
1792:"    call lex",
1793:"",
1794:"    ; Parse",
1923:"; order, and each module visited once. Runtime initializers are NOT yet supplied.",
1924:"; Source-path diagnostics point at the importing file and directive line.",
1925:"; ============================================================",
1926:"graph_preflight_v1:",
1927:"    lea rdi,[rel source_buf]",
1928:"    lea rsi,[rel graph_v1_header]",
1929:"    xor rcx,rcx",
1940:".header_end:",
1941:"    ; Require end of header line: a partial prefix is not an opt-in.",
1942:"    cmp byte [rdi+rcx],10",
1943:"    je .go",
1944:"    cmp byte [rdi+rcx],13",
1945:"    jne .skip",
1946:".go:",
1947:"    mov qword [rel graph_count],0",
1948:"    mov qword [rel graph_depth],0",
}
for n,s in slots.items(): lines[n-1]=s+'\n'
before=''.join(lines);after=p.update(before)
diff=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/src/sutram_compiler.asm',tofile='b/src/sutram_compiler.asm',n=1))
# None of the spacer lines may be included in a hunk.
if '; R42 PATCH-BUILDER SPACER' in diff:
    raise SystemExit('ERROR: synthetic context leaked into patch')
(R/'R42_STAGE1_UNASSEMBLED.patch').write_text(diff)
print('Created patch:',R/'R42_STAGE1_UNASSEMBLED.patch',len(diff),'bytes')
