"""Static safety checks of NASM source patcher; NOT NASM compilation."""
import importlib.util
from pathlib import Path
import unittest
P=Path(__file__).with_name('apply_r42_stage1.py')
spec=importlib.util.spec_from_file_location('apply_r42_stage1',P)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
class PatchStaticTests(unittest.TestCase):
    def setUp(self):
        self.original=''.join(old+'\n' for old,_ in mod.CHANGES[:-1])
    def test_all_expected_anchors_apply(self):
        new=mod.update(self.original)
        self.assertIn('r42_validate_export_declarations:',new)
        self.assertIn('call r42_blank_niryat_directives',new)
        self.assertIn('graph_msg_export_undefined',new)
    def test_refuses_repeat_apply(self):
        new=mod.update(self.original)
        with self.assertRaisesRegex(ValueError,'already present'): mod.update(new)
    def test_refuses_stale_source(self):
        with self.assertRaisesRegex(ValueError,'baseline anchor'):mod.update('BITS 64\n')
    def test_legacy_gate_present(self):
        self.assertIn('cmp qword [rel r42_enabled],0\n    je .disabled',mod.STAGE1_CODE)
        self.assertIn('cmp qword [rel r42_enabled],0\n    je .done',mod.STAGE1_CODE)
    def test_bracket_balance(self):
        code=mod.STAGE1_CODE
        self.assertEqual(code.count('['),code.count(']'))
        self.assertGreater(code.count('r42_'),15)
if __name__=='__main__':unittest.main(verbosity=2)
