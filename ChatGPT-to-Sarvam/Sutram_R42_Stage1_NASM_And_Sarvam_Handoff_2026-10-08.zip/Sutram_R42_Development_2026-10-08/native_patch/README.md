# Round 42 NASM Stage 1 — UNASSEMBLED, NOT MERGE-READY

This folder contains an **actual proposed modification to `src/sutram_compiler.asm`**, expressed as an exact-anchor patcher. It is more than a Python specification or an independent oracle: running it produces a modified single-file handwritten NASM compiler source. However, **no full source file, assembled executable, or native acceptance result is shipped here**.

## Exact baseline and application

The original file's SHA-256 from Sarvam's Round 42 handoff is:

`cd7a290883c085685a8ef71d8486e8a23a43b5498f4588fd7b08ef2290978598`

Its Git blob SHA confirmed during inspection was `b05d536b369923a023fc81fcdda2d2d4d324745f`. At the last HEAD checked (`aab754481a98051a9e66bcd3efe65932d21e65b7`), the three newer changes affected Linux GUI/docs/tests and **not** the compiler.

From repository root:

```sh
python3 path/to/apply_r42_stage1.py src/sutram_compiler.asm /tmp/sutram_compiler_r42_stage1.asm
# inspect the diff (do NOT replace the repository source yet):
diff -u --label a/src/sutram_compiler.asm --label b/src/sutram_compiler.asm \
  src/sutram_compiler.asm /tmp/sutram_compiler_r42_stage1.asm > /tmp/R42_STAGE1_UNVERIFIED.patch || test "$?" -eq 1
```

If the checksum is wrong or the source anchors differ, the patcher **aborts**, not guesses.

## Implemented in proposed NASM code

- Gate all changes behind the exact `# sutram-module-v1` root header.
- Reuse R41 `graph_buffers`, `graph_lengths`, and `graph_paths` to check `niryat symbol` has a same-module `prakriya` or `sutra` *lexical declaration*.
- Produce `E_EXPORT_UNDEFINED` through existing `graph_error`, with original module filename, export line, and symbol.
- Replace opt-in `niryat` directive text with spaces before `lex`, preserving source length and physical newline offsets.
- Do not change the legacy import path at all when root has no v1 header.

## NOT IMPLEMENTED — MUST BE COMPLETED BY SARVAM / NEXT ROUND

- Namespaced/private symbol lowering, and impossible-to-bypass privacy, especially for unqualified imports.
- `E_PRIVATE_SYMBOL`, `E_EXPORT_COLLISION`, qualified references to absent names, and transitive re-export semantics.
- Native support for top-level exported `sutra` constants; `parse_function` currently accepts top-level `prakriya`/`rachana`/`ayojan` but does not accept top-level `sutra`.
- Lexical string/comment state for directive detection (multiline strings can currently be misidentified as declarations). Parsing metadata must be hardened before merge.
- Actual NASM compilation, Linux/Windows native execution, exact goldens, regression gates and GUI visual acceptance.

**Do not merge this prototype to `main` until all remaining items are addressed.** A Python patcher for developing the NASM source is allowed by project policy; it is not a Sutram runtime dependency or an alternative compiler.
