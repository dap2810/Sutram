# ChatGPT → Sarvam — Round 42 partial contract/test handoff

**Prepared:** 2026-10-08 local / 2026-10-09 UTC  
**Source repository:** https://github.com/dap2810/Sutram  
**Last observed `main` HEAD:** `751cbd3be02a7576954ec1bcca3304a7c5b87b36`  
**Latest inbound handoff verified:** `Sarvam-to-ChatGPT/ROUND-42.md`  
**Delivery:** local ZIP artifact only, **no GitHub push**  
**Acceptance status:** **INCOMPLETE — native `niryat` compiler implementation was not made.**

## STATUS

I read the latest repository overview, Sarvam handoff, main commit list, module graph preflight, transitive import expansion, and namespaced rewrite code. R42 remains the latest inbound instruction. I did **not** change `src/sutram_compiler.asm` because I cannot assemble the modified source or run the required native suite in this environment, and a partial visibility check without actual private-symbol lowering would falsely suggest isolation. Thus R42 is **not ready to merge**.

I prepared a constrained **development-only reference-model patch**, two runnable Python test programs, eight pending native fixture sets, an implementation map to NASM call sites, and an owner-facing Windows GUI manual checklist. None is a replacement for a compiler or a native `.out` golden.

## CHANGED (proposed, local only)

- `tools/module_graph_reference.py`: recognize `sutra NAME = expr` separately from `prakriya NAME(...)` so constants count as defined in the Python oracle. Distinguish an absent qualified symbol (`E_EXPORT_UNDEFINED`) from a defined-but-private qualified symbol (`E_PRIVATE_SYMBOL`).
- `tools/test_r42_export_contract.py`: 13 reference-model tests including legacy behavior, qualified access, collision, undefined/duplicate export, alias isolation, constants, diamond and missing module.
- `tools/test_r42_pending_fixtures.py`: 8 reference-oracle checks against the supplied pending `.sm`/`.smlib` fixture sets.
- `tests/r42_exports/`: 8 fixture directories, native result *shape* captured in `EXPECTED.txt`, no fake `.out` or `.exit` data.
- `tests/gui/R42_OWNER_MANUAL_CHECKLIST.md`: GUI owner manual checks; **not run visually**.
- `compiler/ROUND42_EXPORT_VISIBILITY_DESIGN.md`: detailed NASM integration sequence, compatibility boundary and constraints.
- `patches/R42_REFERENCE_ONLY.patch`: unified diff of reference model **only**. Does not edit the compiler.
- `README.md`, `MANIFEST.sha256`, this report.

## TESTS — actually run

```
python3 tools/test_r42_export_contract.py
Ran 13 tests in 0.005s
OK

python3 tools/test_r42_pending_fixtures.py
ORACLE fixture checks 8/8 PASS (NO NATIVE COMPILER)
```

Patch verification commands (see separate verification log after pack finalization): `git apply --check`, apply/reverse roundtrip against local reconstruction of upstream reference-model content. **This is not proof the patch applies to any newer GitHub HEAD; recheck first.**

**NOT RUN:** `nasm ... src/sutram_compiler.asm`, Linux ELF compiler, Windows PE32+ compiler, 181 expected native regressions, 12 codegen gates, language pack native tests, R41 native acceptance, Windows GUI launch/visual acceptance, X11 visual run. No claim of 185/185 or any performance gain.

## BENCHMARKS

No native compiler or program performance was benchmarked. The Python reference tests' reported runtime is not a Sutram benchmark.

## SOURCE INTEGRITY

- Authoritative newer Round 41 compiler SHA-256, as **reported by Sarvam** in Round 42: `cd7a290883c085685a8ef71d8486e8a23a43b5498f4588fd7b08ef2290978598`. Not recomputed locally from the complete assembly file.
- Latest GitHub compiler blob SHA (Git SHA-1, **not** file SHA-256) returned by connector: `b05d536b369923a023fc81fcdda2d2d4d324745f`.
- Every file in this review ZIP is covered by `MANIFEST.sha256` except the manifest itself; update the manifest if making any edits after handoff generation.
- `patches/R42_REFERENCE_ONLY.patch` changes **only** the Python oracle. There is deliberately no compiler diff.

## BLOCKED

1. GitHub branch creation `feature/r42-export-contract-preflight` from HEAD returned **403 Resource not accessible by integration**. I did not push and did not try editing `main`.
2. An exact recursive GitHub tree of `main` returned 351 entries and **no `tests/` directory**, even though the R42 handoff references `tests/run_tests.py`, `tests/expect/`, GUI manual checks and 181 passing tests. Hence native acceptance cannot be reconstructed from the visible checkout. This differs from the historical handoff's reported verified test environment; it does not invalidate Sarvam's prior independent results.
3. Local tool check found `/usr/bin/ld` but no `nasm`; `git clone` failed with DNS resolution error. The complete compiler was read from GitHub as content, but cannot be built/tested locally from this runtime.
4. Module-level `sutra` parsing in real NASM language grammar needs verification before promoting that fixture.

## NEXT — Sarvam acceptance/development steps

1. Restore or commit the full reproducible native test tree, ensure NASM and linker are installed in a standard-user build environment, and verify current compiler SHA against latest branch history.
2. Apply `R42_REFERENCE_ONLY.patch` to the developer-only reference model if desired; independently check its exact contract choices (undefined versus private, constants, alias semantics).
3. Implement the real `niryat` visibility in **`src/sutram_compiler.asm`**, using the design mapping. A preflight registry alone is insufficient; private symbols must be hygienically lowered/renamed to prevent access through global AST symbols.
4. Promote pending `tests/r42_exports/*` examples to native compiler regression fixtures **only after** recording actual compiler status, stdout, stderr and output bytes. Fix any example grammar mismatch without hiding a compiler defect.
5. Rebuild Linux and Windows from current NASM source; pass at least 185 native cases (181 + 4), 12 codegen gates and existing R41 module tests; test whether historic generated ELF/PE remain byte-identical for non-opt-in inputs.
6. Run GUI checklist on Windows or mark NOT RUN; provide real screenshots only if captured. Generate final source SHA-256 manifest, roundtrip patch, dated GitHub report and feature branch/PR once integration writes work.

**No compiler feature or GitHub handoff was delivered as complete.** The attached contract tests are intended to reduce ambiguity and catch errors when actual NASM implementation resumes.
