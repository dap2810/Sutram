#!/usr/bin/env python3
"""Round 42 standalone CONTRACT tests of Python graph ORACLE, NOT NASM.
Run: python3 tools/test_r42_export_contract.py
This deliberately does not invent native .out goldens or verify compiled code.
"""
import tempfile
import unittest
from pathlib import Path
from module_graph_reference import GraphReference, GraphDiagnostic

class ExportTests(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory(prefix='sutram-r42-')
        self.addCleanup(self.td.cleanup)
        self.root = Path(self.td.name)
        self.lib = self.root/'lib'
        self.lib.mkdir()
        self.ref = GraphReference(self.lib)

    def src(self, text):
        p = self.root/'main.sm'
        p.write_text(text, encoding='utf-8')
        return p

    def module(self, name, text):
        p = self.lib/f'{name}.smlib'
        p.write_text(text, encoding='utf-8')
        return p

    def reject(self, kind, fn, *details):
        with self.assertRaises(GraphDiagnostic) as catch:
            fn()
        self.assertEqual(catch.exception.kind, kind)
        self.assertTrue(all(part in str(catch.exception) for part in details))
        return catch.exception

    def test_exported_function_available(self):
        self.module('calc', '# sutram-module-v1\nniryat add\nprakriya add() { pratiyati helper() }\nprakriya helper() { pratiyati 4 }\n')
        self.assertEqual(self.ref.analyze(self.src('# sutram-module-v1\nayojan calc@c\n')), ['calc'])
        self.assertTrue(self.ref.check_access('calc', 'add', self.root/'main.sm', 3))

    def test_private_qualified_reference_rejected(self):
        self.module('calc', '# sutram-module-v1\nniryat add\nprakriya add() { pratiyati helper() }\nprakriya helper() { pratiyati 4 }\n')
        entry = self.src('# sutram-module-v1\nayojan calc@c\nmukhya() { likha(c__helper()) }\n')
        self.ref.analyze(entry)
        e = self.reject('E_PRIVATE_SYMBOL', lambda: self.ref.check_access('calc', 'helper', entry, 3), 'main.sm:3', 'calc.helper')
        self.assertIn('niryat helper', str(e))

    def test_undefined_export_diagnostic(self):
        self.module('calc', '# sutram-module-v1\nniryat absent\nprakriya present() { pratiyati 2 }\n')
        self.reject('E_EXPORT_UNDEFINED', lambda: self.ref.analyze(self.src('# sutram-module-v1\nayojan calc\n')), 'calc.smlib:2', 'absent')

    def test_duplicate_export_diagnostic(self):
        self.module('calc', '# sutram-module-v1\nniryat add\nniryat add\nprakriya add() { pratiyati 1 }\n')
        self.reject('E_EXPORT_DUPLICATE', lambda: self.ref.analyze(self.src('# sutram-module-v1\nayojan calc\n')), 'calc.smlib:3', 'add')

    def test_unqualified_collision_names_both_modules(self):
        for m in ('alpha','beta'):
            self.module(m, '# sutram-module-v1\nniryat both\nprakriya both() { pratiyati 1 }\n')
        self.reject('E_EXPORT_COLLISION', lambda: self.ref.analyze(self.src('# sutram-module-v1\nayojan alpha\nayojan beta\n')), 'both', 'alpha', 'beta')

    def test_aliases_isolate_colliding_exports(self):
        for m in ('alpha','beta'):
            self.module(m, '# sutram-module-v1\nniryat both\nprakriya both() { pratiyati 1 }\n')
        self.assertEqual(self.ref.analyze(self.src('# sutram-module-v1\nayojan alpha@a\nayojan beta@b\n')), ['alpha', 'beta'])

    def test_legacy_functions_remain_public_in_oracle(self):
        self.module('legacy', 'prakriya old() { pratiyati 1 }\nprakriya helper() { pratiyati 2 }\n')
        entry = self.src('ayojan legacy\n')
        self.ref.analyze(entry)
        self.assertTrue(self.ref.check_access('legacy', 'helper', entry, 3))

    def test_opt_in_sutra_constant_export(self):
        self.module('config', '# sutram-module-v1\nniryat MAX_VAL\nsutra MAX_VAL = 64\n')
        entry = self.src('# sutram-module-v1\nayojan config\n')
        self.assertEqual(self.ref.analyze(entry), ['config'])
        self.assertTrue(self.ref.check_access('config', 'MAX_VAL', entry, 3))

    def test_legacy_sutra_constant_visible(self):
        self.module('config', 'sutra LEGACY_MAX = 64\n')
        entry = self.src('ayojan config\n')
        self.ref.analyze(entry)
        self.assertTrue(self.ref.check_access('config', 'LEGACY_MAX', entry, 3))

    def test_private_name_collision_does_not_collide_exports(self):
        for m in ('alpha','beta'):
            self.module(m, '# sutram-module-v1\nniryat public_'+m+'\nprakriya public_'+m+'() { pratiyati helper() }\nprakriya helper() { pratiyati 1 }\n')
        entry = self.src('# sutram-module-v1\nayojan alpha@a\nayojan beta@b\n')
        self.assertEqual(self.ref.analyze(entry), ['alpha','beta'])

    def test_missing_module_honors_importer_location(self):
        self.reject('E_MODULE_MISSING', lambda: self.ref.analyze(self.src('# sutram-module-v1\nayojan missing\n')), 'main.sm:2')

    def test_diamond_once_only(self):
        self.module('left', 'ayojan shared\nprakriya l() { pratiyati 2 }\n')
        self.module('right', 'ayojan shared\nprakriya r() { pratiyati 3 }\n')
        self.module('shared', 'prakriya common() { pratiyati 1 }\n')
        self.assertEqual(self.ref.analyze(self.src('# sutram-module-v1\nayojan left\nayojan right\n')), ['shared','left','right'])

    def test_missing_qualified_export_not_auto_exposed(self):
        self.module('calc', '# sutram-module-v1\nniryat public\nprakriya public() { pratiyati 1 }\n')
        entry = self.src('# sutram-module-v1\nayojan calc@c\n')
        self.ref.analyze(entry)
        self.reject('E_EXPORT_UNDEFINED', lambda: self.ref.check_access('calc','not_declared', entry, 9), 'main.sm:9', 'calc.not_declared')

if __name__ == '__main__':
    unittest.main(verbosity=2)
