#!/usr/bin/env python3
"""Run native R42 export fixtures against a newly assembled Sutram compiler.

Requires NASM and ld. Does not pretend an old checked-in binary is an R42
verification. Goldens are intentionally shape-only until native output is run,
then the integrator should record actual .out/.exit/.compile_fail expectations.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
FIXTURES=ROOT/'tests'/'r42_exports'
CASE_SPECS={
  '01_success_alias_public':{'stdout_contains':['42'],'exit':0},
  '02_fail_export_undefined':{'error':'E_EXPORT_UNDEFINED','terms':['calc.smlib','missing']},
  '03_fail_export_collision':{'error':'E_EXPORT_COLLISION','terms':['alpha','beta','both']},
  '04_fail_qualified_private':{'error':'E_PRIVATE_SYMBOL','terms':['main.sm','helper']},
  '05_success_alias_collision_isolated':{'stdout_contains':['1','2'],'exit':0},
  '06_success_legacy_unchanged':{'stdout_contains':['73'],'exit':0},
  '08_fail_qualified_undefined':{'error':'E_EXPORT_UNDEFINED','terms':['main.sm','missing']},
}

def run(cmd:list[str], timeout:int=45):
    return subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--repository',type=Path,required=True,help='Complete repo checkout; build must use this source')
    ap.add_argument('--allow-stage1',action='store_true',help='For diagnostic exploration only, not acceptance')
    args=ap.parse_args()
    repo=args.repository.resolve()
    source=repo/'src'/'sutram_compiler.asm'
    if not source.is_file():
        print('BLOCKED: compiler source absent:',source);return 2
    missing=[x for x in ('nasm','ld') if shutil.which(x) is None]
    if missing:
        print('BLOCKED: native build tools missing:',','.join(missing));return 2
    if 'r42_validate_export_declarations:' in source.read_text(errors='replace'):
        print('NOTE: This source includes the R42 Stage-1 prototype; full visibility remains unverified.')
    with tempfile.TemporaryDirectory(prefix='sutram-r42-native-') as temp:
        d=Path(temp)
        asm=run(['nasm','-f','elf64',str(source),'-o',str(d/'sutram.o')])
        print('NASM rc:',asm.returncode,'\n',asm.stdout,asm.stderr)
        if asm.returncode: return 1
        ld=run(['ld','-o',str(d/'sutram_compiler'),str(d/'sutram.o')])
        print('LD rc:',ld.returncode,'\n',ld.stdout,ld.stderr)
        if ld.returncode:return 1
        fails=0
        for name,spec in CASE_SPECS.items():
            case=FIXTURES/name
            src=case/'main.sm';out=d/(name+'.bin')
            c=run([str(d/'sutram_compiler'),str(src),str(out)])
            both=c.stdout+c.stderr
            if 'error' in spec:
                ok=c.returncode !=0 and spec['error'] in both and all(w in both for w in spec['terms'])
                print(('PASS' if ok else 'FAIL'),name,'compile rc',c.returncode,'diagnostic',repr(both))
            else:
                ok=False
                if c.returncode==0 and out.is_file():
                    p=run([str(out)])
                    ok=p.returncode==spec['exit'] and all(s in p.stdout for s in spec['stdout_contains'])
                    print(('PASS' if ok else 'FAIL'),name,'output rc',p.returncode,'stdout',repr(p.stdout))
                else:
                    print('FAIL',name,'compile rc',c.returncode,'diagnostic',repr(both))
            fails+=not ok
        print(f'R42 NATIVE RESULT: {len(CASE_SPECS)-fails}/{len(CASE_SPECS)} checks passed; goldens still require recording.')
        print('07_success_sutra_constant: NOT RUN -- top-level sutra grammar unsupported by parser; requires separate implementation')
        return 1 if fails else 0
if __name__=='__main__':sys.exit(main())
