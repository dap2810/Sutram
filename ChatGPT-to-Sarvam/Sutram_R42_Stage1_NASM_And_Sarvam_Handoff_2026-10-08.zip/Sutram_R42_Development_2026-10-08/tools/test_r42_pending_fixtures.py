#!/usr/bin/env python3
"""Check recorded R42 fixture outcomes against the independent Python oracle.

No NASM source is assembled, and no native executable is run here.
"""
from pathlib import Path
import re
from module_graph_reference import GraphReference, GraphDiagnostic

ROOT = Path(__file__).resolve().parents[1]/'tests'/'r42_exports'
EXPECTED = {
 '01_success_alias_public': None,
 '02_fail_export_undefined': 'E_EXPORT_UNDEFINED',
 '03_fail_export_collision': 'E_EXPORT_COLLISION',
 '04_fail_qualified_private': 'E_PRIVATE_SYMBOL',
 '05_success_alias_collision_isolated': None,
 '06_success_legacy_unchanged': None,
 '07_success_sutra_constant': None,
 '08_fail_qualified_undefined': 'E_EXPORT_UNDEFINED',
}

CALL = re.compile(r'\b([A-Za-z_][A-Za-z_0-9]*)__([A-Za-z_][A-Za-z_0-9]*)\s*\(')

def check_case(case: Path):
    entry = case/'main.sm'
    r = GraphReference(case/'lib')
    r.analyze(entry)
    # The current Python oracle does not parse expressions, so explicitly ask
    # it to check each import-qualified call discovered in the caller source.
    # This is a reference-contract fixture check, not lexer proof.
    for line_number,line in enumerate(entry.read_text().splitlines(),1):
        for match in CALL.finditer(line):
            alias,symbol = match.group(1),match.group(2)
            if alias in r.import_map:
                r.check_access(r.import_map[alias],symbol,entry,line_number)


def main():
    success = 0
    for name, expected in EXPECTED.items():
        case = ROOT/name
        if not (case/'main.sm').exists() or not (case/'EXPECTED.txt').exists():
            raise AssertionError(f'fixture incomplete: {name}')
        try:
            check_case(case)
        except GraphDiagnostic as err:
            if expected != err.kind:
                raise AssertionError(f'{name}: got {err.kind} ({err}), expected {expected}') from err
            print(f'PASS ORACLE FIXTURE {name}: {err.kind}')
        else:
            if expected is not None:
                raise AssertionError(f'{name}: unexpectedly accepted, expected {expected}')
            print(f'PASS ORACLE FIXTURE {name}: accepted')
        success += 1
    print(f'ORACLE fixture checks {success}/{len(EXPECTED)} PASS (NO NATIVE COMPILER)')

if __name__ == '__main__':
    main()
